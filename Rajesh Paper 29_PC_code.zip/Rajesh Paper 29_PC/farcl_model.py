"""
================================================================================
Federated Alpha-Regularized Continual Learning (FARCL)
Implements Spatial-Temporal CNN-BiGRU architecture with alpha-regularized loss
to eliminate catastrophic forgetting in dynamic vehicular intrusion detection.
================================================================================
"""

import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from typing import Dict, List, Tuple
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

from config import FARCL_CONFIG, ATTACK_CLASSES

class SpatialTemporalCNNBiGRU(nn.Module):
    """
    Combines 1D-CNN (Spatial feature extraction) and Bi-GRU (Temporal dynamics)
    with self-attention pooling for vehicular intrusion detection.
    """
    def __init__(self, num_features: int = 12, cnn_filters: int = 32, hidden_dim: int = 64, num_classes: int = 5):
        super(SpatialTemporalCNNBiGRU, self).__init__()
        
        # 1. 1D Convolutional Layer for spatial feature extraction
        self.conv1d = nn.Sequential(
            nn.Conv1d(in_channels=num_features, out_channels=cnn_filters, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_filters),
            nn.ReLU(),
            nn.Dropout(0.15)
        )
        
        # 2. Bidirectional Gated Recurrent Unit for temporal modeling
        self.bigru = nn.GRU(
            input_size=cnn_filters,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True
        )
        
        # 3. Attention mechanism
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )
        
        # 4. Classification head
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [batch_size, seq_len, num_features]
        """
        # Transpose for Conv1D: [batch_size, num_features, seq_len]
        x_trans = x.transpose(1, 2)
        spatial_feat = self.conv1d(x_trans)
        
        # Transpose back for BiGRU: [batch_size, seq_len, cnn_filters]
        spatial_feat = spatial_feat.transpose(1, 2)
        gru_out, _ = self.bigru(spatial_feat)
        
        # Attention pooling over timesteps: [batch_size, seq_len, 1]
        attn_weights = F.softmax(self.attention(gru_out), dim=1)
        context = torch.sum(gru_out * attn_weights, dim=1)
        
        logits = self.fc(context)
        return logits

    def get_weights(self) -> Dict[str, torch.Tensor]:
        return {k: v.cpu().clone() for k, v in self.state_dict().items()}

    def set_weights(self, weights: Dict[str, torch.Tensor]):
        self.load_state_dict(weights)


class FARCLClient:
    """
    Cluster Head (CH) client running local training with Alpha-Regularized Continual Learning.
    L_FARCL = L_CE + (alpha / 2) * sum(Omega_i * (theta_i - theta_i^*)^2)
    """
    def __init__(self, client_id: int, train_dataset: Dataset, alpha_reg: float = 0.50):
        self.client_id = client_id
        self.alpha_reg = alpha_reg
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SpatialTemporalCNNBiGRU().to(self.device)
        self.train_loader = DataLoader(train_dataset, batch_size=FARCL_CONFIG["batch_size"], shuffle=True)
        
        # Continual Learning anchors
        self.optimal_weights: Optional[Dict[str, torch.Tensor]] = None
        self.fisher_information: Dict[str, torch.Tensor] = {}

    def compute_fisher_information(self):
        """
        Computes diagonal Fisher Information Matrix (Omega) to measure parameter importance.
        """
        self.model.eval()
        fisher = {k: torch.zeros_like(p, device=self.device) for k, p in self.model.named_parameters()}
        criterion = nn.CrossEntropyLoss()
        
        for batch_x, batch_y in self.train_loader:
            batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
            self.model.zero_grad()
            outputs = self.model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            
            for k, p in self.model.named_parameters():
                if p.grad is not None:
                    fisher[k] += p.grad.data ** 2
                    
        for k in fisher.keys():
            fisher[k] = fisher[k] / float(len(self.train_loader))
        self.fisher_information = fisher

    def train_local(self, global_weights: Dict[str, torch.Tensor], epochs: int = FARCL_CONFIG["local_epochs"]) -> Dict[str, torch.Tensor]:
        """
        Local continual training regularized with alpha penalty to prevent catastrophic forgetting.
        """
        self.model.set_weights(global_weights)
        self.model.train()
        
        optimizer = optim.Adam(self.model.parameters(), lr=FARCL_CONFIG["learning_rate"], weight_decay=1e-4)
        criterion = nn.CrossEntropyLoss()
        
        for _ in range(epochs):
            for batch_x, batch_y in self.train_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                optimizer.zero_grad()
                outputs = self.model(batch_x)
                ce_loss = criterion(outputs, batch_y)
                
                # Alpha-regularized continual learning penalty
                reg_loss = 0.0
                if self.optimal_weights is not None and self.fisher_information:
                    for k, p in self.model.named_parameters():
                        if k in self.optimal_weights:
                            opt_p = self.optimal_weights[k].to(self.device)
                            fish = self.fisher_information.get(k, torch.ones_like(p))
                            reg_loss += torch.sum(fish * (p - opt_p) ** 2)
                            
                total_loss = ce_loss + (self.alpha_reg / 2.0) * reg_loss
                total_loss.backward()
                optimizer.step()
                
        # Save current state as anchor for next continual phase
        self.optimal_weights = {k: v.clone() for k, v in self.model.state_dict().items()}
        self.compute_fisher_information()
        return self.model.get_weights()


class FARCLServer:
    """
    Base Station (BS) server coordinating Reputation-Weighted Federated Aggregation.
    """
    def __init__(self, test_dataset: Dataset):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.global_model = SpatialTemporalCNNBiGRU().to(self.device)
        self.test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

    def aggregate_weights(self, client_updates: List[Tuple[int, Dict[str, torch.Tensor], int]], reputation_scores: Dict[int, float]):
        """
        Reputation-weighted federated aggregation:
        alpha_k = (Rep_k * n_k) / sum(Rep_j * n_j)
        """
        if not client_updates:
            return
            
        weights_list = []
        eff_reps = []
        samples_list = []
        
        for c_id, weights, n_samples in client_updates:
            rep = reputation_scores.get(c_id, 0.85)
            if rep >= 0.50:  # Untrusted / compromised CHs are excluded
                weights_list.append(weights)
                eff_reps.append(rep)
                samples_list.append(n_samples)
                
        if not weights_list:
            return
            
        raw_weights = [r * n for r, n in zip(eff_reps, samples_list)]
        norm_weights = [w / sum(raw_weights) for w in raw_weights]
        
        agg = copy.deepcopy(weights_list[0])
        for k in agg.keys():
            agg[k] = torch.zeros_like(agg[k], dtype=torch.float32)
            for w_dict, alpha in zip(weights_list, norm_weights):
                agg[k] += alpha * w_dict[k].to(torch.float32)
                
        self.global_model.set_weights(agg)

    def evaluate(self) -> Dict[str, Any]:
        """
        Evaluates global intrusion detection metrics:
        Accuracy, Precision, Recall, F1-Score, FNR, and Sybil Attack Detection Rate.
        """
        self.global_model.eval()
        preds, targets, probs = [], [], []
        
        with torch.no_grad():
            for batch_x, batch_y in self.test_loader:
                batch_x = batch_x.to(self.device)
                logits = self.global_model(batch_x)
                p = torch.softmax(logits, dim=1).cpu().numpy()
                preds.extend(np.argmax(p, axis=1))
                targets.extend(batch_y.numpy())
                probs.extend(p)
                
        y_true = np.array(targets)
        y_pred = np.array(preds)
        
        acc = accuracy_score(y_true, y_pred) * 100.0
        prec = precision_score(y_true, y_pred, average='weighted', zero_division=0) * 100.0
        rec = recall_score(y_true, y_pred, average='weighted', zero_division=0) * 100.0
        f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0) * 100.0
        
        # Binary confusion: Normal (0) vs Attack (1, 2, 3, 4)
        y_true_bin = (y_true > 0).astype(int)
        y_pred_bin = (y_pred > 0).astype(int)
        cm_bin = confusion_matrix(y_true_bin, y_pred_bin)
        
        tn, fp, fn, tp = cm_bin.ravel() if cm_bin.shape == (2, 2) else (1, 0, 0, 1)
        fnr = (fn / max(1, fn + tp)) * 100.0  # False Negative Rate
        
        # Sybil Detection Rate: Class 1
        sybil_mask = (y_true == 1)
        sybil_detected = np.sum((y_pred == 1) & sybil_mask)
        sybil_total = np.sum(sybil_mask)
        sybil_rate = (sybil_detected / max(1, sybil_total)) * 100.0
        
        cfm = confusion_matrix(y_true, y_pred, labels=list(range(FARCL_CONFIG["num_classes"])))
        
        return {
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "false_negative_rate": fnr,
            "sybil_detection_rate": sybil_rate,
            "confusion_matrix": cfm.tolist(),
            "y_true": y_true,
            "y_pred": y_pred,
            "y_probs": np.array(probs)
        }
