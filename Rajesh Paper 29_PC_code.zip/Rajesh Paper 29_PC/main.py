"""
================================================================================
Master Execution Pipeline for:
Trust-Aware Clustering based Congestion Control and Malicious Attack Mitigation
for Reliable VANET Data Sharing in Blockchain
================================================================================
"""

import os
import sys
import time
import random
import numpy as np
from typing import Dict, Any

from config import (
    TOPOLOGY_CONFIG, RW_ABFT_CONFIG, CTLO_CONFIG, FARCL_CONFIG, VRT_CONFIG,
    RESULTS_DIR, ATTACK_CLASSES
)
from vanet_topology import ThreeTierVanetEnvironment
from vrt_rate_limit import VRTManager
from blockchain_rw_abft import RWABFTBlockchain, VanetTransaction
from dataset_generator import TrafficDatasetGenerator
from farcl_model import FARCLClient, FARCLServer
from ctlo_optimizer import CTLORoutingOptimizer, CTLOEngine
from metrics_evaluator import MetricsEvaluator
from visualizer import VisualizerPaper29

def run_pipeline() -> Dict[str, Any]:
    print("=" * 80)
    print("STARTING COMPLETE RESEARCH SIMULATION PIPELINE (PAPER 29)")
    print("Title: Trust-Aware Clustering based Congestion Control and Malicious Attack Mitigation")
    print("       for Reliable VANET Data Sharing in Blockchain")
    print("=" * 80)
    
    t_start = time.time()
    
    # -------------------------------------------------------------------------
    # STEP 1: Initialize 3-Tier VANET Topology (BSs, CHs, SNs)
    # -------------------------------------------------------------------------
    print("\n[Step 1/6] Initializing 3-Tier VANET Topology & Dynamic Clustering...")
    env = ThreeTierVanetEnvironment(TOPOLOGY_CONFIG)
    print(f"  -> Deployed {len(env.base_stations)} Base Stations (BSs) as Edge Infrastructure.")
    print(f"  -> Elected {len(env.cluster_heads)} Cluster Heads (CHs) for Local Cluster Management.")
    print(f"  -> Deployed {len(env.sensor_nodes)} Vehicular Sensor Nodes (SNs).")
    malicious_count = sum(1 for sn in env.sensor_nodes.values() if sn.is_malicious)
    print(f"  -> Compromised/Adversarial Nodes: {malicious_count} ({malicious_count/len(env.sensor_nodes)*100:.1f}%)")
    
    # Simulate initial kinematics and cluster formation
    for _ in range(5):
        env.step()
    print("  -> Clusters formed dynamically based on proximity, speed-delta, and reputation.")

    # -------------------------------------------------------------------------
    # STEP 2: Verifiable Rate-Limit Tokens (VRTs) & Access Control
    # -------------------------------------------------------------------------
    print("\n[Step 2/6] Enforcing Access Control with Verifiable Rate-Limit Tokens (VRTs)...")
    vrt_manager = VRTManager(VRT_CONFIG)
    
    throttled_count = 0
    allowed_count = 0
    for sn_id, sn in env.sensor_nodes.items():
        token = vrt_manager.issue_token(sn_id)
        sn.vrt_tokens = token.capacity
        
        # Test rate consumption
        is_allowed, reason = vrt_manager.check_and_consume(sn_id, sn.is_malicious, sn.attack_type)
        if not is_allowed:
            sn.is_throttled = True
            throttled_count += 1
        else:
            allowed_count += 1
            
    print(f"  -> VRTs Issued: {vrt_manager.tokens_issued}")
    print(f"  -> Authorized Traffic Passes: {allowed_count}")
    print(f"  -> DDoS / Flooding Nodes Throttled at Edge: {throttled_count}")

    # -------------------------------------------------------------------------
    # STEP 3: Blockchain Registration & RW-ABFT Consensus
    # -------------------------------------------------------------------------
    print("\n[Step 3/6] Executing RW-ABFT Blockchain Consensus & On-Chain Evidence Logging...")
    blockchain = RWABFTBlockchain(RW_ABFT_CONFIG)
    
    # Register Base Stations and Cluster Heads
    committee_ids = []
    for bs_id in env.base_stations.keys():
        nid = f"BS_{bs_id}"
        blockchain.register_node(nid, initial_rep=1.0)
        committee_ids.append(nid)
    for ch_id in env.cluster_heads.keys():
        nid = f"CH_{ch_id}"
        blockchain.register_node(nid, initial_rep=0.95)
        committee_ids.append(nid)
        
    # Submit transactions to mempool: authentication events and security evidence
    for sn_id, sn in env.sensor_nodes.items():
        is_auth = blockchain.verify_authentication(sn_id, sn.is_malicious)
        sn.authenticated = is_auth
        
        # Update node reputation on ledger
        blockchain.update_reputation(f"SN_{sn_id}", is_honest=(not sn.is_malicious), direct_fidelity=0.95 if not sn.is_malicious else 0.20)
        
        tx_auth = VanetTransaction(
            tx_type="AUTH_CERT",
            sender_id=f"SN_{sn_id}",
            receiver_id="BS_0",
            payload={"sn_id": sn_id, "authenticated": is_auth, "cluster_id": sn.cluster_id}
        )
        blockchain.submit_transaction(tx_auth)
        
        # Verify data integrity of traffic telemetry
        telemetry = {"sn_id": sn_id, "speed": round(sn.speed, 2), "cluster": sn.cluster_id}
        claimed_h = VanetTransaction("TELEMETRY", f"SN_{sn_id}", "BS_0", telemetry).tx_id
        blockchain.verify_data_integrity(telemetry, claimed_h)

    # Run RW-ABFT consensus across committee
    proposer_idx = 0
    while blockchain.mempool:
        proposer = committee_ids[proposer_idx % len(committee_ids)]
        blockchain.run_rw_abft_consensus(committee_nodes=committee_ids, proposer_id=proposer)
        proposer_idx += 1
        
    rw_abft_metrics = blockchain.get_metrics()
    print("  -> RW-ABFT Consensus Finished:")
    print(f"     * Total Blocks Committed: {rw_abft_metrics['total_blocks']}")
    print(f"     * Transactions Committed: {rw_abft_metrics['total_committed_txs']}")
    print(f"     * Blockchain Latency: {rw_abft_metrics['blockchain_transaction_latency_s']:.3f} s")
    print(f"     * Authentication Success Rate: {rw_abft_metrics['authentication_success_rate_pct']:.2f}%")
    print(f"     * Data Integrity Success Rate: {rw_abft_metrics['data_integrity_verification_success_rate_pct']:.2f}%")

    # -------------------------------------------------------------------------
    # STEP 4: Spatial-Temporal Traffic Generation & FARCL Training
    # -------------------------------------------------------------------------
    print("\n[Step 4/6] Training FARCL (Spatial-Temporal CNN-BiGRU with Alpha-Regularization)...")
    dataset_gen = TrafficDatasetGenerator(num_features=FARCL_CONFIG["num_features"], seq_len=10)
    train_ds, test_ds = dataset_gen.build_dataset(num_samples=2500, test_ratio=0.25)
    
    server = FARCLServer(test_ds)
    num_ch_clients = len(env.cluster_heads)
    samples_per_ch = len(train_ds) // num_ch_clients
    clients = []
    
    for ch_id in range(num_ch_clients):
        # Subset dataset for local cluster
        sub_indices = list(range(ch_id * samples_per_ch, (ch_id + 1) * samples_per_ch))
        from torch.utils.data import Subset
        sub_ds = Subset(train_ds, sub_indices)
        client = FARCLClient(client_id=ch_id, train_dataset=sub_ds, alpha_reg=FARCL_CONFIG["alpha_reg"])
        clients.append(client)
        
    print(f"  -> Coordinated {len(clients)} Cluster Head Clients for Federated Continual Learning.")
    print(f"  -> Running {FARCL_CONFIG['num_rounds']} Rounds with Alpha-Regularization (alpha = {FARCL_CONFIG['alpha_reg']})...")
    
    ch_reputations = {ch_id: env.cluster_heads[ch_id].reputation_score for ch_id in range(num_ch_clients)}
    
    for rnd in range(1, FARCL_CONFIG["num_rounds"] + 1):
        global_w = server.global_model.get_weights()
        client_updates = []
        
        for client in clients:
            w_local = client.train_local(global_w, epochs=FARCL_CONFIG["local_epochs"])
            client_updates.append((client.client_id, w_local, len(client.train_loader.dataset)))
            
        server.aggregate_weights(client_updates, ch_reputations)
        
        if rnd % 5 == 0 or rnd == FARCL_CONFIG["num_rounds"]:
            eval_inter = server.evaluate()
            print(f"     Round {rnd:02d}/{FARCL_CONFIG['num_rounds']:02d} | Accuracy: {eval_inter['accuracy']:.2f}% | F1-Score: {eval_inter['f1_score']:.2f}% | Sybil Detection: {eval_inter['sybil_detection_rate']:.2f}%")

    farcl_metrics = server.evaluate()
    print("  -> FARCL Continual Learning Evaluation Complete:")
    print(f"     * Accuracy: {farcl_metrics['accuracy']:.2f}%")
    print(f"     * Precision: {farcl_metrics['precision']:.2f}%")
    print(f"     * Recall: {farcl_metrics['recall']:.2f}%")
    print(f"     * F1-Score: {farcl_metrics['f1_score']:.2f}%")
    print(f"     * False Negative Rate (FNR): {farcl_metrics['false_negative_rate']:.2f}%")
    print(f"     * Sybil Attack Detection Rate: {farcl_metrics['sybil_detection_rate']:.2f}%")

    # -------------------------------------------------------------------------
    # STEP 5: CTLO Routing & Congestion Control Simulation
    # -------------------------------------------------------------------------
    print("\n[Step 5/6] Executing CTLO Adaptive Routing & Congestion Control...")
    optimizer = CTLORoutingOptimizer(env, CTLO_CONFIG)
    routing_engine = CTLOEngine(env, optimizer)
    
    # Generate sensor data traffic
    routing_engine.generate_traffic(num_packets=220)
    
    # Route packets through CHs with lungfish estivation & cocoon protection
    for _ in range(15):
        env.step()
        ctlo_metrics = routing_engine.route_traffic(blockchain.reputation_registry)
        
    print("  -> CTLO Routing Simulation Complete:")
    print(f"     * Packet Delivery Ratio (PDR): {ctlo_metrics['pdr_pct']:.2f}%")
    print(f"     * Packet Loss Rate: {ctlo_metrics['packet_loss_rate_pct']:.2f}%")
    print(f"     * Secure Message Delivery Rate: {ctlo_metrics['secure_message_delivery_rate_pct']:.2f}%")
    print(f"     * Average End-to-End Delay: {ctlo_metrics['avg_end_to_end_delay_ms']:.2f} ms")
    print(f"     * Network Throughput: {ctlo_metrics['network_throughput_kbps']:.2f} kbps")

    # -------------------------------------------------------------------------
    # STEP 6: Consolidate Metrics, Benchmarks & Generate Visualizations
    # -------------------------------------------------------------------------
    print("\n[Step 6/6] Consolidating All 15 Metrics & Generating 300 DPI Figures...")
    evaluator = MetricsEvaluator()
    final_metrics = evaluator.aggregate_metrics(farcl_metrics, ctlo_metrics, rw_abft_metrics)
    comp_df = evaluator.create_comparative_table()
    
    json_path, csv_path = evaluator.save_reports()
    print(f"  -> Saved Metrics JSON: {json_path}")
    print(f"  -> Saved Comparison CSV: {csv_path}")
    
    viz = VisualizerPaper29(RESULTS_DIR)
    
    # 1. Confusion Matrix (Times New Roman, bold, size 20 inside values!)
    fig1 = viz.plot_confusion_matrix(farcl_metrics["confusion_matrix"])
    print(f"  -> [Fig 1] Confusion Matrix saved: {fig1}")
    
    # 2. ROC Curves
    fig2 = viz.plot_roc_curves(farcl_metrics["y_true"], farcl_metrics["y_probs"])
    print(f"  -> [Fig 2] Multi-class ROC Curves saved: {fig2}")
    
    # 3. Scalability Analysis
    fig3 = viz.plot_scalability()
    print(f"  -> [Fig 3] Scalability Analysis saved: {fig3}")
    
    # 4. Delay vs Congestion
    fig4 = viz.plot_delay_vs_congestion()
    print(f"  -> [Fig 4] Delay vs Congestion saved: {fig4}")
    
    # 5. Blockchain Latency
    fig5 = viz.plot_blockchain_latency()
    print(f"  -> [Fig 5] Blockchain Latency saved: {fig5}")
    
    # 6. Comparative Benchmark Summary
    fig6 = viz.plot_comparative_summary(comp_df)
    print(f"  -> [Fig 6] Comparative Summary saved: {fig6}")
    
    total_time = time.time() - t_start
    print(f"\nSimulation successfully finished in {total_time:.2f} seconds.")
    print("=" * 80)
    print("FINAL SUMMARY OF ALL 15 EVALUATION METRICS (PAPER 29):")
    print("=" * 80)
    for k, v in final_metrics.items():
        print(f"  {k:<46}: {v}")
    print("=" * 80)
    
    return final_metrics

if __name__ == "__main__":
    run_pipeline()
