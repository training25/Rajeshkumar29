"""
================================================================================
Clustering-based Trust-Aware Lungfish Optimizer (CTLO) for Routing & Congestion Control
Bio-inspired algorithm mimicking lungfish estivation, mucus cocoon fortification,
and swimming bursts to select optimal secure routes and control network congestion.
================================================================================
"""

import math
import random
import numpy as np
from typing import List, Dict, Tuple, Optional
from config import CTLO_CONFIG, TOPOLOGY_CONFIG
from vanet_topology import ThreeTierVanetEnvironment, ClusterHead, SensorNode, BaseStation

class VanetPacket:
    """
    Represents a data packet traveling from an SN through CHs to a destination BS.
    """
    def __init__(self, pkt_id: int, source_sn_id: int, dest_bs_id: int, creation_time: float, size_bits: int = 8192):
        self.pkt_id = pkt_id
        self.source_sn_id = source_sn_id
        self.dest_bs_id = dest_bs_id
        self.creation_time = creation_time
        self.size_bits = size_bits
        self.current_ch_id: Optional[int] = None
        self.route_hops: List[str] = [f"SN_{source_sn_id}"]
        self.is_delivered: bool = False
        self.is_dropped: bool = False
        self.drop_reason: Optional[str] = None
        self.delivery_time: Optional[float] = None
        self.is_secure_delivered: bool = False


class LungfishAgent:
    """
    Candidate solution representing a multi-hop routing path through CHs to the BS.
    """
    def __init__(self, path: List[int], fitness: float = 0.0):
        self.path = path  # Sequence of CH IDs [CH_src, ..., CH_k]
        self.fitness = fitness
        self.is_estivating: bool = False


class CTLORoutingOptimizer:
    """
    Clustering-based Trust-Aware Lungfish Optimizer (CTLO).
    Controls congestion by anticipating queue overflows and selects trustworthy, stable links.
    """
    def __init__(self, env: ThreeTierVanetEnvironment, config: Dict = CTLO_CONFIG):
        self.env = env
        self.cfg = config
        self.pop_size = config["population_size"]
        self.max_iter = config["max_iterations"]
        self.estivation_thresh = config["estivation_threshold"]
        self.cocoon_factor = config["mucus_cocoon_factor"]
        self.burrow_scale = config["burrowing_depth_scale"]
        self.burst_speed = config["swimming_burst_speed"]
        
        # Objective weights
        self.w_trust = config["w_trust"]
        self.w_lq = config["w_link_quality"]
        self.w_cong = config["w_congestion"]
        self.w_delay = config["w_delay"]

    def evaluate_fitness(self, path: List[int], dest_bs_id: int, reputation_scores: Dict[str, float]) -> float:
        """
        Calculates composite multi-objective fitness:
        f = w_trust * Trust + w_lq * LinkQuality - w_cong * Congestion - w_delay * Delay
        """
        if not path:
            return -1.0
            
        bs = self.env.base_stations[dest_bs_id]
        trust_vals = []
        lq_vals = []
        max_queue_ratio = 0.0
        
        for i in range(len(path)):
            ch_curr = self.env.cluster_heads[path[i]]
            rep = reputation_scores.get(f"CH_{ch_curr.ch_id}", ch_curr.reputation_score)
            trust_vals.append(rep)
            
            # Queue occupancy
            q_ratio = ch_curr.queue_occupancy / float(ch_curr.max_queue_size)
            if q_ratio > max_queue_ratio:
                max_queue_ratio = q_ratio
                
            # Link quality to next hop
            if i < len(path) - 1:
                ch_next = self.env.cluster_heads[path[i + 1]]
                lq = self.env.calculate_link_quality(ch_curr, ch_next)
                norm_snr = np.clip(lq["snr"] / 35.0, 0.0, 1.0)
                norm_let = np.clip(lq["let"] / 40.0, 0.0, 1.0)
                lq_vals.append(0.5 * norm_snr + 0.5 * norm_let)
            else:
                # Link to destination BS
                dist_to_bs = math.hypot(ch_curr.x - bs.x, ch_curr.y - bs.y)
                lq_vals.append(np.clip(1.0 - (dist_to_bs / bs.coverage_radius), 0.1, 1.0))
                
        avg_trust = float(np.mean(trust_vals))
        avg_lq = float(np.mean(lq_vals)) if lq_vals else 0.5
        
        # Delay penalty: hop count and final distance to BS
        last_ch = self.env.cluster_heads[path[-1]]
        final_dist = math.hypot(last_ch.x - bs.x, last_ch.y - bs.y)
        delay_penalty = (len(path) / 6.0) * 0.5 + (final_dist / self.env.width) * 0.5
        
        fitness = (
            self.w_trust * avg_trust +
            self.w_lq * avg_lq -
            self.w_cong * max_queue_ratio -
            self.w_delay * delay_penalty
        )
        return float(fitness)

    def optimize_route(self, src_ch_id: int, dest_bs_id: int, reputation_scores: Dict[str, float]) -> List[int]:
        """
        Executes CTLO bio-inspired optimization to find the best multi-hop path.
        """
        bs = self.env.base_stations[dest_bs_id]
        available_chs = list(self.env.cluster_heads.keys())
        
        # Direct reach check
        src_ch = self.env.cluster_heads[src_ch_id]
        if math.hypot(src_ch.x - bs.x, src_ch.y - bs.y) <= bs.coverage_radius:
            return [src_ch_id]
            
        # Initialize population of lungfish agents
        population: List[LungfishAgent] = []
        for _ in range(self.pop_size):
            # Generate random loopless path
            hops = random.randint(1, min(4, len(available_chs)))
            candidate = [src_ch_id]
            pool = [c for c in available_chs if c != src_ch_id]
            for _ in range(hops - 1):
                if pool:
                    nxt = random.choice(pool)
                    candidate.append(nxt)
                    pool.remove(nxt)
            fit = self.evaluate_fitness(candidate, dest_bs_id, reputation_scores)
            population.append(LungfishAgent(path=candidate, fitness=fit))
            
        # Optimization iterations
        for it in range(self.max_iter):
            population.sort(key=lambda a: a.fitness, reverse=True)
            best_agent = population[0]
            
            for agent in population:
                # Estivation check: if path contains congested node, enter estivation
                has_congestion = any(
                    (self.env.cluster_heads[c].queue_occupancy / float(self.env.cluster_heads[c].max_queue_size)) >= self.estivation_thresh
                    for c in agent.path
                )
                
                if has_congestion:
                    # Estivation & Mucus Cocoon Phase:
                    # Filter out congested nodes and enforce high-reputation detour
                    agent.is_estivating = True
                    safe_pool = [
                        c for c in available_chs
                        if (self.env.cluster_heads[c].queue_occupancy / float(self.env.cluster_heads[c].max_queue_size)) < self.estivation_thresh
                        and reputation_scores.get(f"CH_{c}", 0.8) >= 0.60
                    ]
                    if safe_pool:
                        detour_hop = random.choice(safe_pool)
                        agent.path = [src_ch_id, detour_hop]
                        agent.fitness = self.evaluate_fitness(agent.path, dest_bs_id, reputation_scores) * self.cocoon_factor
                else:
                    # Burrowing (local exploitation) vs Swimming (exploration)
                    agent.is_estivating = False
                    if random.random() < 0.60:
                        # Burrowing Phase: fine-tune intermediate hops towards best path
                        if len(best_agent.path) > 1 and len(agent.path) > 1:
                            agent.path[1] = best_agent.path[1]
                    else:
                        # Swimming Burst Phase: explore new candidate forwarder
                        pool = [c for c in available_chs if c not in agent.path]
                        if pool:
                            agent.path.append(random.choice(pool))
                    agent.fitness = self.evaluate_fitness(agent.path, dest_bs_id, reputation_scores)
                    
        population.sort(key=lambda a: a.fitness, reverse=True)
        return population[0].path


class CTLOEngine:
    """
    Simulation engine routing packets generated by SNs through CHs to BSs.
    Computes PDR, Packet Loss Rate, Delay, Throughput, and Secure Delivery Rate.
    """
    def __init__(self, env: ThreeTierVanetEnvironment, optimizer: CTLORoutingOptimizer):
        self.env = env
        self.optimizer = optimizer
        self.packets: List[VanetPacket] = []
        self.delivered_packets: List[VanetPacket] = []
        self.dropped_packets: List[VanetPacket] = []
        self.pkt_counter: int = 0

    def generate_traffic(self, num_packets: int = 200):
        """Generate vehicular sensor data packets."""
        sn_ids = list(self.env.sensor_nodes.keys())
        bs_ids = list(self.env.base_stations.keys())
        
        for _ in range(num_packets):
            src = random.choice(sn_ids)
            dest = random.choice(bs_ids)
            pkt = VanetPacket(
                pkt_id=self.pkt_counter,
                source_sn_id=src,
                dest_bs_id=dest,
                creation_time=self.env.current_time
            )
            self.pkt_counter += 1
            self.packets.append(pkt)

    def route_traffic(self, reputation_scores: Dict[str, float]) -> Dict[str, float]:
        """
        Executes routing with CTLO congestion control and VRT validation.
        """
        for pkt in self.packets:
            if pkt.is_delivered or pkt.is_dropped:
                continue
                
            sn = self.env.sensor_nodes[pkt.source_sn_id]
            sn.packets_sent += 1
            
            # Rate-limiting check at source
            if sn.is_throttled:
                pkt.is_dropped = True
                pkt.drop_reason = "VRT_Throttled_Drop"
                sn.packets_dropped += 1
                self.dropped_packets.append(pkt)
                continue
                
            # If source is malicious (e.g. DoS / Spoofing)
            if sn.is_malicious and sn.attack_type == 2:  # DDoS
                pkt.is_dropped = True
                pkt.drop_reason = "DDoS_Suppressed_At_Edge"
                sn.packets_dropped += 1
                self.dropped_packets.append(pkt)
                continue
                
            src_ch_id = sn.ch_id
            if src_ch_id is None:
                src_ch_id = 0
                
            # Optimize routing path using CTLO
            path = self.optimizer.optimize_route(src_ch_id, pkt.dest_bs_id, reputation_scores)
            
            # Forward through CH path
            hop_success = True
            total_hops = len(path)
            
            for ch_id in path:
                ch = self.env.cluster_heads[ch_id]
                # Check buffer overflow
                if ch.queue_occupancy >= ch.max_queue_size:
                    pkt.is_dropped = True
                    pkt.drop_reason = "CH_Queue_Overflow"
                    self.dropped_packets.append(pkt)
                    hop_success = False
                    break
                    
                ch.queue_occupancy += 1
                ch.update_position(0.1, self.env.width, self.env.height)
                ch.queue_occupancy = max(0, ch.queue_occupancy - 1)
                pkt.route_hops.append(f"CH_{ch_id}")
                
            if hop_success:
                # Reached final CH, deliver to destination BS
                pkt.is_delivered = True
                pkt.route_hops.append(f"BS_{pkt.dest_bs_id}")
                
                # Per-hop propagation + queuing latency (6.0 - 11.5 ms per hop)
                per_hop_delay = random.uniform(6.5, 11.0)
                pkt.delivery_time = pkt.creation_time + (total_hops * per_hop_delay / 1000.0)
                
                # Check secure delivery: untampered and non-malicious
                pkt.is_secure_delivered = not sn.is_malicious
                sn.packets_delivered += 1
                self.delivered_packets.append(pkt)
                
        return self.compute_metrics()

    def compute_metrics(self) -> Dict[str, float]:
        """
        Calculates:
        - Packet Delivery Ratio (PDR %)
        - Packet Loss Rate (%)
        - Secure Message Delivery Rate (%)
        - Average End-to-End Delay (ms)
        - Network Throughput (kbps)
        """
        total = len(self.packets)
        delivered = len(self.delivered_packets)
        
        pdr = (delivered / max(1, total)) * 100.0
        packet_loss_rate = 100.0 - pdr
        
        secure_delivered = sum(1 for p in self.delivered_packets if p.is_secure_delivered)
        secure_delivery_rate = (secure_delivered / max(1, total)) * 100.0
        
        if delivered > 0:
            delays = [(p.delivery_time - p.creation_time) * 1000.0 for p in self.delivered_packets if p.delivery_time]
            avg_delay = float(np.mean(delays))
        else:
            avg_delay = 120.0
            
        total_delivered_bits = sum(p.size_bits for p in self.delivered_packets)
        duration = max(1.0, self.env.current_time)
        throughput_kbps = (total_delivered_bits / duration) / 1000.0
        
        return {
            "pdr_pct": round(pdr, 2),
            "packet_loss_rate_pct": round(packet_loss_rate, 2),
            "secure_message_delivery_rate_pct": round(secure_delivery_rate, 2),
            "avg_end_to_end_delay_ms": round(avg_delay, 2),
            "network_throughput_kbps": round(throughput_kbps, 2)
        }
