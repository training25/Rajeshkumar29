"""
================================================================================
Three-Tier VANET Network Topology Architecture
Implements Base Stations (BSs), Cluster Heads (CHs), and Sensor Nodes (SNs)
with dynamic clustering, channel physics, queue congestion, and mobility.
================================================================================
"""

import math
import random
import numpy as np
from typing import List, Dict, Tuple, Optional
from config import TOPOLOGY_CONFIG, ATTACK_CLASSES

class SensorNode:
    """
    Tier-1: Vehicular Sensor Node (SN) collecting and transmitting traffic data.
    """
    def __init__(self, sn_id: int, x: float, y: float, vx: float, vy: float, is_malicious: bool = False, attack_type: int = 0):
        self.sn_id = sn_id
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.speed = math.hypot(vx, vy)
        self.heading = math.atan2(vy, vx)
        
        self.is_malicious = is_malicious
        self.attack_type = attack_type  # 0: Normal, 1: Sybil, 2: DDoS, 3: Spoofing, 4: Replay
        
        # Cluster association
        self.cluster_id: Optional[int] = None
        self.ch_id: Optional[int] = None
        
        # Security & Reputation
        self.reputation_score: float = 0.85
        self.authenticated: bool = False
        self.vrt_tokens: int = 0
        self.vrt_last_refill: float = 0.0
        self.is_throttled: bool = False
        self.throttle_until: float = 0.0
        
        # Performance & Queue State
        self.queue_occupancy: int = 0
        self.max_queue_size: int = TOPOLOGY_CONFIG["max_queue_size"]
        self.packets_sent: int = 0
        self.packets_delivered: int = 0
        self.packets_dropped: int = 0
        self.energy_joules: float = 100.0

    def update_position(self, dt: float, area_w: float, area_h: float):
        """Update vehicle kinematics with boundary wrapping and realistic velocity variations."""
        acc = random.uniform(-1.2, 1.2)
        self.speed = np.clip(self.speed + acc * dt, TOPOLOGY_CONFIG["min_speed"], TOPOLOGY_CONFIG["max_speed"])
        self.heading += random.uniform(-0.04, 0.04)
        
        self.vx = self.speed * math.cos(self.heading)
        self.vy = self.speed * math.sin(self.heading)
        
        self.x += self.vx * dt
        self.y += self.vy * dt
        
        # Soft boundary bounce
        if self.x < 0 or self.x > area_w:
            self.vx = -self.vx
            self.x = np.clip(self.x, 0, area_w)
            self.heading = math.atan2(self.vy, self.vx)
        if self.y < 0 or self.y > area_h:
            self.vy = -self.vy
            self.y = np.clip(self.y, 0, area_h)
            self.heading = math.atan2(self.vy, self.vx)

    def consume_energy(self, duration_sec: float, mode: str = "idle"):
        tx_p = TOPOLOGY_CONFIG["tx_power_watt"]
        rx_p = TOPOLOGY_CONFIG["rx_power_watt"]
        power = tx_p if mode == "tx" else (rx_p if mode == "rx" else 0.05)
        self.energy_joules = max(0.0, self.energy_joules - power * duration_sec)


class ClusterHead:
    """
    Tier-2: Cluster Head (CH) aggregating local cluster traffic, verifying VRTs,
    running local FARCL updates, and acting as RW-ABFT consensus committee member.
    """
    def __init__(self, ch_id: int, x: float, y: float, vx: float, vy: float):
        self.ch_id = ch_id
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.speed = math.hypot(vx, vy)
        self.heading = math.atan2(vy, vx)
        
        self.members: List[int] = []    # List of associated SN IDs
        self.reputation_score: float = 0.95
        self.queue_occupancy: int = 0
        self.max_queue_size: int = TOPOLOGY_CONFIG["max_queue_size"] * 2
        self.coverage_radius: float = TOPOLOGY_CONFIG["tx_range_ch"]
        self.is_congested: bool = False
        self.connected_bs: Optional[int] = None

    def update_position(self, dt: float, area_w: float, area_h: float):
        """Update CH spatial position along major arterial corridors."""
        self.x += self.vx * dt
        self.y += self.vy * dt
        if self.x < 0 or self.x > area_w:
            self.vx = -self.vx
            self.x = np.clip(self.x, 0, area_w)
        if self.y < 0 or self.y > area_h:
            self.vy = -self.vy
            self.y = np.clip(self.y, 0, area_h)


class BaseStation:
    """
    Tier-3: Roadside Base Station (BS) with wide wireless coverage and blockchain storage.
    """
    def __init__(self, bs_id: int, x: float, y: float):
        self.bs_id = bs_id
        self.x = x
        self.y = y
        self.coverage_radius: float = TOPOLOGY_CONFIG["tx_range_bs"]
        self.managed_chs: List[int] = []
        self.reputation_score: float = 1.0


class ThreeTierVanetEnvironment:
    """
    Complete physical and network perception layer environment for 3-tier VANET.
    """
    def __init__(self, config: Dict = TOPOLOGY_CONFIG):
        self.cfg = config
        self.width = config["area_width"]
        self.height = config["area_height"]
        self.current_time: float = 0.0
        
        self.sensor_nodes: Dict[int, SensorNode] = {}
        self.cluster_heads: Dict[int, ClusterHead] = {}
        self.base_stations: Dict[int, BaseStation] = {}
        
        self._initialize_infrastructure()
        self._initialize_sensor_nodes()
        self.form_clusters()

    def _initialize_infrastructure(self):
        """Deploy Base Stations and Cluster Heads across the road network."""
        # 1. Base Stations (BSs) deployed uniformly in 4 quadrants
        n_bs = self.cfg["num_base_stations"]
        dx = self.width / 3.0
        dy = self.height / 3.0
        coords_bs = [
            (dx, dy), (2 * dx, dy),
            (dx, 2 * dy), (2 * dx, 2 * dy)
        ]
        for i in range(n_bs):
            x, y = coords_bs[i]
            self.base_stations[i] = BaseStation(bs_id=i, x=x, y=y)
            
        # 2. Cluster Heads (CHs) distributed along network axes
        n_ch = self.cfg["num_cluster_heads"]
        for i in range(n_ch):
            x = random.uniform(150.0, self.width - 150.0)
            y = random.uniform(150.0, self.height - 150.0)
            speed = random.uniform(12.0, 25.0)
            angle = random.uniform(0, 2 * math.pi)
            self.cluster_heads[i] = ClusterHead(
                ch_id=i,
                x=x,
                y=y,
                vx=speed * math.cos(angle),
                vy=speed * math.sin(angle)
            )

    def _initialize_sensor_nodes(self):
        """Spawn vehicular Sensor Nodes with legitimate and malicious tags."""
        n_sn = self.cfg["num_sensor_nodes"]
        mal_count = int(n_sn * self.cfg["malicious_ratio"])
        attack_pool = [1, 2, 3, 4]  # 1: Sybil, 2: DDoS, 3: Spoofing, 4: Replay
        
        for sn_id in range(n_sn):
            x = random.uniform(50.0, self.width - 50.0)
            y = random.uniform(50.0, self.height - 50.0)
            speed = random.uniform(self.cfg["min_speed"], self.cfg["max_speed"])
            angle = random.uniform(0, 2 * math.pi)
            
            is_mal = sn_id < mal_count
            atk_type = random.choice(attack_pool) if is_mal else 0
            
            sn = SensorNode(
                sn_id=sn_id,
                x=x,
                y=y,
                vx=speed * math.cos(angle),
                vy=speed * math.sin(angle),
                is_malicious=is_mal,
                attack_type=atk_type
            )
            if is_mal:
                sn.reputation_score = random.uniform(0.30, 0.45)
            self.sensor_nodes[sn_id] = sn

    def form_clusters(self):
        """
        Dynamically clusters Sensor Nodes (SNs) around the optimal Cluster Head (CH).
        Clustering metric = w1 * (1/dist) + w2 * (1/speed_delta) + w3 * CH_reputation.
        """
        for ch in self.cluster_heads.values():
            ch.members.clear()
            
        for sn in self.sensor_nodes.values():
            best_ch = None
            best_score = -float("inf")
            for ch_id, ch in self.cluster_heads.items():
                dist = math.hypot(sn.x - ch.x, sn.y - ch.y)
                if dist <= ch.coverage_radius:
                    speed_delta = abs(sn.speed - ch.speed) + 0.5
                    score = (150.0 / dist) + (10.0 / speed_delta) + (ch.reputation_score * 5.0)
                    if score > best_score:
                        best_score = score
                        best_ch = ch_id
                        
            if best_ch is not None:
                sn.ch_id = best_ch
                sn.cluster_id = best_ch
                self.cluster_heads[best_ch].members.append(sn.sn_id)
            else:
                # If out of reach of any CH, find the closest one
                closest_ch = min(self.cluster_heads.keys(), key=lambda c: math.hypot(sn.x - self.cluster_heads[c].x, sn.y - self.cluster_heads[c].y))
                sn.ch_id = closest_ch
                sn.cluster_id = closest_ch
                self.cluster_heads[closest_ch].members.append(sn.sn_id)

    def step(self):
        """Step simulation forward by dt seconds."""
        self.current_time += self.cfg["time_step"]
        dt = self.cfg["time_step"]
        
        # 1. Update kinematics
        for sn in self.sensor_nodes.values():
            sn.update_position(dt, self.width, self.height)
            sn.consume_energy(dt, mode="idle")
            
        for ch in self.cluster_heads.values():
            ch.update_position(dt, self.width, self.height)
            # Congestion check
            ch.is_congested = (ch.queue_occupancy / float(ch.max_queue_size)) >= 0.70
            
        # 2. Dynamic re-clustering periodically
        if int(self.current_time) % 5 == 0:
            self.form_clusters()

    def calculate_link_quality(self, node_a, node_b) -> Dict[str, float]:
        """Calculates distance, path loss, SNR, and Link Expiration Time (LET)."""
        dist = max(1.0, math.hypot(node_a.x - node_b.x, node_a.y - node_b.y))
        path_loss = 40.0 + 10.0 * self.cfg["path_loss_exponent"] * math.log10(dist)
        rssi = 27.0 - path_loss  # 27 dBm = 0.5W
        snr = max(0.0, rssi - self.cfg["noise_floor_dbm"])
        
        # Theoretical Link Expiration Time (LET)
        R = TOPOLOGY_CONFIG["tx_range_ch"]
        dx = node_a.x - node_b.x
        dy = node_a.y - node_b.y
        dvx = node_a.vx - node_b.vx
        dvy = node_a.vy - node_b.vy
        
        a = dvx**2 + dvy**2
        b = 2.0 * (dx * dvx + dy * dvy)
        c = dx**2 + dy**2 - R**2
        
        let = 60.0
        if a > 1e-4:
            disc = b**2 - 4.0 * a * c
            if disc >= 0:
                times = [(-b + math.sqrt(disc)) / (2.0 * a), (-b - math.sqrt(disc)) / (2.0 * a)]
                pos_times = [t for t in times if t > 0]
                if pos_times:
                    let = min(pos_times)
                    
        return {
            "distance": dist,
            "path_loss": path_loss,
            "rssi": rssi,
            "snr": snr,
            "let": max(0.1, min(let, 120.0))
        }
