"""
================================================================================
Quick Launcher & CLI Runner for Paper 29 Research Simulation
Allows custom parameters: Sensor Nodes (SNs), Cluster Heads, BSs, and FARCL rounds.
================================================================================
"""

import argparse
import sys
from config import TOPOLOGY_CONFIG, FARCL_CONFIG
from main import run_pipeline

def main():
    parser = argparse.ArgumentParser(
        description="Trust-Aware Clustering Congestion Control & Attack Mitigation in Blockchain VANET"
    )
    parser.add_argument("--sensor_nodes", type=int, default=TOPOLOGY_CONFIG["num_sensor_nodes"], help="Number of Sensor Nodes (SNs)")
    parser.add_argument("--cluster_heads", type=int, default=TOPOLOGY_CONFIG["num_cluster_heads"], help="Number of Cluster Heads (CHs)")
    parser.add_argument("--base_stations", type=int, default=TOPOLOGY_CONFIG["num_base_stations"], help="Number of Base Stations (BSs)")
    parser.add_argument("--rounds", type=int, default=FARCL_CONFIG["num_rounds"], help="FARCL federated learning rounds")
    parser.add_argument("--malicious_ratio", type=float, default=TOPOLOGY_CONFIG["malicious_ratio"], help="Ratio of adversarial nodes")
    
    args = parser.parse_args()
    
    TOPOLOGY_CONFIG["num_sensor_nodes"] = args.sensor_nodes
    TOPOLOGY_CONFIG["num_cluster_heads"] = args.cluster_heads
    TOPOLOGY_CONFIG["num_base_stations"] = args.base_stations
    TOPOLOGY_CONFIG["malicious_ratio"] = args.malicious_ratio
    FARCL_CONFIG["num_rounds"] = args.rounds
    
    print(f"Launching Simulation (Paper 29) with:")
    print(f"  Sensor Nodes (SNs): {TOPOLOGY_CONFIG['num_sensor_nodes']}")
    print(f"  Cluster Heads (CHs): {TOPOLOGY_CONFIG['num_cluster_heads']}")
    print(f"  Base Stations (BSs): {TOPOLOGY_CONFIG['num_base_stations']}")
    print(f"  Adversarial Ratio: {TOPOLOGY_CONFIG['malicious_ratio'] * 100:.1f}%")
    print(f"  FARCL Rounds: {FARCL_CONFIG['num_rounds']}")
    
    run_pipeline()

if __name__ == "__main__":
    main()
