"""
================================================================================
Spatial-Temporal Dataset Generator for VANET Intrusion Detection
Generates multi-feature traffic sequences for Normal, Sybil, DDoS, Spoofing, and Replay attacks.
================================================================================
"""

import numpy as np
import torch
from torch.utils.data import Dataset
from typing import Tuple
from config import FARCL_CONFIG, ATTACK_CLASSES

class VanetTrafficDataset(Dataset):
    """PyTorch Dataset holding multi-timestep vehicular traffic sequences."""
    def __init__(self, sequences: np.ndarray, labels: np.ndarray):
        self.sequences = torch.tensor(sequences, dtype=torch.float32)
        self.labels = torch.tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.sequences[idx], self.labels[idx]


class TrafficDatasetGenerator:
    """
    Generates realistic spatial-temporal traffic logs with physical channel characteristics.
    """
    def __init__(self, num_features: int = 12, seq_len: int = 10, seed: int = 42):
        self.num_features = num_features
        self.seq_len = seq_len
        np.random.seed(seed)

    def generate_sequence(self, attack_type: int) -> np.ndarray:
        """
        Features:
        0: packet_rate (pkts/sec)
        1: inter_arrival_time (ms)
        2: packet_drop_ratio (0-1)
        3: rssi (dBm)
        4: snr (dB)
        5: doppler_velocity_delta (m/s)
        6: hop_count (1-6)
        7: payload_size (bytes)
        8: transmission_jitter (ms)
        9: queue_occupancy_ratio (0-1)
        10: vrt_token_validity_flag (1=valid, 0=invalid/exhausted)
        11: timestamp_drift (ms)
        """
        seq = np.zeros((self.seq_len, self.num_features))
        
        for t in range(self.seq_len):
            if attack_type == 0:  # Normal
                pkt_rate = np.random.normal(16.0, 3.0)
                iat = np.random.normal(62.0, 8.0)
                pdr = np.clip(np.random.normal(0.03, 0.01), 0.0, 0.1)
                rssi = np.random.normal(-65.0, 4.0)
                snr = np.random.normal(26.0, 3.5)
                v_delta = np.random.normal(1.0, 0.4)
                hops = np.random.choice([1, 2, 3])
                payload = np.random.normal(512, 40)
                jitter = np.random.normal(3.5, 1.0)
                queue = np.clip(np.random.normal(0.25, 0.05), 0.0, 0.5)
                vrt_flag = 1.0
                ts_drift = np.random.normal(2.0, 1.0)
                
            elif attack_type == 1:  # Sybil Attack
                pkt_rate = np.random.normal(48.0, 8.0)
                iat = np.random.normal(20.0, 4.0)
                pdr = np.clip(np.random.normal(0.12, 0.03), 0.0, 0.25)
                rssi = np.random.normal(-82.0, 10.0)  # Inconsistent signal from phantom locations
                snr = np.random.normal(15.0, 5.0)
                v_delta = np.random.normal(9.0, 2.5)   # Fake coordinates vs physical Doppler
                hops = 1
                payload = np.random.normal(384, 30)
                jitter = np.random.normal(8.0, 2.0)
                queue = np.clip(np.random.normal(0.50, 0.08), 0.2, 0.8)
                vrt_flag = 0.0                        # Multiple phantom IDs lacking individual VRTs
                ts_drift = np.random.normal(12.0, 4.0)
                
            elif attack_type == 2:  # DDoS / Flooding
                pkt_rate = np.random.normal(195.0, 25.0)  # Massive traffic flood
                iat = np.random.normal(4.5, 1.0)
                pdr = np.clip(np.random.normal(0.70, 0.1), 0.4, 0.95)
                rssi = np.random.normal(-56.0, 3.0)
                snr = np.random.normal(19.0, 3.0)
                v_delta = np.random.normal(2.5, 0.8)
                hops = np.random.choice([1, 2])
                payload = np.random.normal(1024, 100)
                jitter = np.random.normal(25.0, 5.0)
                queue = np.clip(np.random.normal(0.96, 0.03), 0.8, 1.0)  # Queue saturation
                vrt_flag = 0.0                         # Exhausted token quota
                ts_drift = np.random.normal(5.0, 2.0)
                
            elif attack_type == 3:  # Spoofing / False Information
                pkt_rate = np.random.normal(28.0, 5.0)
                iat = np.random.normal(36.0, 6.0)
                pdr = np.clip(np.random.normal(0.18, 0.04), 0.05, 0.35)
                rssi = np.random.normal(-79.0, 7.0)
                snr = np.random.normal(16.0, 3.5)
                v_delta = np.random.normal(24.0, 5.0)  # Severe kinematic discrepancy
                hops = np.random.choice([1, 2])
                payload = np.random.normal(600, 50)
                jitter = np.random.normal(9.0, 2.0)
                queue = np.clip(np.random.normal(0.40, 0.06), 0.1, 0.6)
                vrt_flag = 1.0
                ts_drift = np.random.normal(8.0, 2.5)
                
            elif attack_type == 4:  # Replay Attack
                pkt_rate = np.random.normal(35.0, 6.0)
                iat = np.random.normal(30.0, 5.0)
                pdr = np.clip(np.random.normal(0.20, 0.05), 0.05, 0.4)
                rssi = np.random.normal(-68.0, 4.0)
                snr = np.random.normal(22.0, 3.0)
                v_delta = np.random.normal(1.2, 0.5)
                hops = np.random.choice([2, 3])
                payload = np.random.normal(512, 40)
                jitter = np.random.normal(18.0, 4.0)
                queue = np.clip(np.random.normal(0.45, 0.08), 0.1, 0.7)
                vrt_flag = 0.0                         # Stale/replayed token from past epoch
                ts_drift = np.random.normal(95.0, 15.0) # Massive timestamp age
                
            seq[t, :] = [
                pkt_rate, iat, pdr, rssi, snr, v_delta,
                hops, payload, jitter, queue, vrt_flag, ts_drift
            ]
            
        return seq

    def build_dataset(self, num_samples: int = 2500, test_ratio: float = 0.25) -> Tuple[VanetTrafficDataset, VanetTrafficDataset]:
        """Builds normalized train and test datasets."""
        X_list, y_list = [], []
        
        # 50% normal, 12.5% each attack class
        n_norm = int(num_samples * 0.50)
        n_atk = int(num_samples * 0.50 / 4)
        
        for _ in range(n_norm):
            X_list.append(self.generate_sequence(0))
            y_list.append(0)
            
        for atk in [1, 2, 3, 4]:
            for _ in range(n_atk):
                X_list.append(self.generate_sequence(atk))
                y_list.append(atk)
                
        X = np.array(X_list)
        y = np.array(y_list)
        
        # Shuffle
        perm = np.random.permutation(len(y))
        X, y = X[perm], y[perm]
        
        # Normalize
        mean = X.mean(axis=(0, 1), keepdims=True)
        std = X.std(axis=(0, 1), keepdims=True) + 1e-6
        X_norm = (X - mean) / std
        
        split = int(len(y) * (1 - test_ratio))
        return VanetTrafficDataset(X_norm[:split], y[:split]), VanetTrafficDataset(X_norm[split:], y[split:])
