import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re

# ---------- Robust CSV reading ----------
file_path = "C:/work/Rajesh Paper 29_PC/results/vanet_paper29_results_comparison.csv"

with open(file_path, "r", encoding="utf-8") as f:
    lines = [line.strip() for line in f if line.strip()]

# Manually define correct columns (ignore the broken header)
cols = [
    "Evaluation Metric",
    "SVM + K-Means",
    "LSTM + AODV",
    "CNN-Attention + PBFT",
    "Proposed (RW-ABFT + CTLO + FARCL + VRT)"
]

data = []
for line in lines[1:]:                          # skip header
    # Split only on commas that are NOT inside brackets
    parts = re.split(r',(?![^\[]*\])', line)
    
    if len(parts) < 5:
        continue
        
    metric = parts[0].strip()
    values = []
    for v in parts[1:5]:
        v = v.strip()
        if v == "" or v.lower() == "nan":
            values.append(0.0)
        else:
            values.append(float(v))
    
    data.append([metric] + values)

df = pd.DataFrame(data, columns=cols)

# ---------- Plotting settings ----------
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'

methods = [
    'SVM + K-Means',
    'LSTM + AODV',
    'CNN-Attention\n+ PBFT',
    'Proposed\n(RW-ABFT + CTLO + FARCL + VRT)'
]

value_cols = [
    "SVM + K-Means",
    "LSTM + AODV",
    "CNN-Attention + PBFT",
    "Proposed (RW-ABFT + CTLO + FARCL + VRT)"
]

colors = ['#e74c3c', '#e67e22', '#3498db', '#2ecc71']
x = np.arange(len(methods))

# ---------- Generate separate graphs ----------
for metric in df["Evaluation Metric"]:
    fig, ax = plt.subplots(figsize=(10, 6))
    
    values = df.loc[df["Evaluation Metric"] == metric, value_cols].values.astype(float)[0]
    
    bars = ax.bar(x, values, color=colors, edgecolor='black', linewidth=1.5, width=0.6)
    
    # Value labels
    for bar, val in zip(bars, values):
        height = bar.get_height()
        if val == 0:
            label = "0.00"
        elif val < 1:
            label = f"{val:.3f}"
        else:
            label = f"{val:.2f}"
        
        ax.annotate(label,
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=13, fontweight='bold')
    
    ax.set_xticks(x)
    ax.set_xticklabels(methods, fontsize=13)
    ax.set_ylabel(metric, fontsize=16, fontweight='bold')
    
    # Legend
    # ax.legend(bars, methods,
    #           loc='lower center',
    #           bbox_to_anchor=(0.5, 1.02),
    #           ncol=2,
    #           fontsize=14,
    #           frameon=True,
    #           edgecolor='black')
    
    # Full border
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.5)
        spine.set_edgecolor('black')
    
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    ax.set_axisbelow(True)
    
    ymax = max(values) * 1.22 if max(values) > 0 else 1
    ax.set_ylim(0, ymax)
    
    plt.tight_layout()
    
    # Clean filename
    safe_name = re.sub(r'[^a-zA-Z0-9]+', '_', metric.lower()).strip('_')
    filename = f"graph_{safe_name}.png"
    
    plt.savefig(filename, dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()
    print(f"Saved: {filename}")

print("\nAll separate graphs generated successfully!")