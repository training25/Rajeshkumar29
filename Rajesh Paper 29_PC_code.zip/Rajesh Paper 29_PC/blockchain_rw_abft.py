"""
================================================================================
Reputation-Weighted Adaptive Byzantine Fault Tolerance (RW-ABFT) Blockchain
Implements reputation-weighted consensus, smart contract evidence aggregation,
authentication validation, and data integrity verification.
================================================================================
"""

import time
import json
import hashlib
from typing import List, Dict, Any, Optional, Tuple
from config import RW_ABFT_CONFIG

def compute_merkle_root(hashes: List[str]) -> str:
    """Computes Merkle Root from a list of transaction hashes."""
    if not hashes:
        return hashlib.sha256(b"empty_rw_abft_block").hexdigest()
    curr = hashes
    while len(curr) > 1:
        nxt = []
        for i in range(0, len(curr), 2):
            left = curr[i]
            right = curr[i + 1] if i + 1 < len(curr) else left
            nxt.append(hashlib.sha256((left + right).encode()).hexdigest())
        curr = nxt
    return curr[0]


class VanetTransaction:
    """
    Represents an on-chain transaction: Auth Record, Evidence Alert, VRT Log, or Data Hash.
    """
    def __init__(self, tx_type: str, sender_id: str, receiver_id: str, payload: Dict[str, Any], timestamp: Optional[float] = None):
        self.timestamp = timestamp or time.time()
        self.tx_type = tx_type      # AUTH_CERT, INTRUSION_ALERT, VRT_ISSUE, DATA_INTEGRITY
        self.sender_id = str(sender_id)
        self.receiver_id = str(receiver_id)
        self.payload = payload
        self.tx_id = self.compute_hash()
        self.commit_timestamp: Optional[float] = None

    def compute_hash(self) -> str:
        data_str = json.dumps({
            "type": self.tx_type,
            "sender": self.sender_id,
            "receiver": self.receiver_id,
            "payload": self.payload,
            "time": self.timestamp
        }, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()


class RWABFTBlock:
    """
    Represents a verified block committed via RW-ABFT consensus.
    """
    def __init__(self, index: int, previous_hash: str, proposer_id: str, transactions: List[VanetTransaction], weighted_quorum: float):
        self.index = index
        self.timestamp = time.time()
        self.previous_hash = previous_hash
        self.proposer_id = proposer_id
        self.transactions = transactions
        self.weighted_quorum = weighted_quorum
        
        tx_hashes = [tx.tx_id for tx in transactions]
        self.merkle_root = compute_merkle_root(tx_hashes)
        self.block_hash = self.compute_hash()

    def compute_hash(self) -> str:
        header = f"{self.index}_{self.previous_hash}_{self.merkle_root}_{self.proposer_id}_{self.timestamp}_{self.weighted_quorum}"
        return hashlib.sha256(header.encode()).hexdigest()


class RWABFTBlockchain:
    """
    Reputation-Weighted Adaptive Byzantine Fault Tolerance (RW-ABFT) Blockchain Engine.
    Committee consists of Base Stations (BSs) and active Cluster Heads (CHs).
    """
    def __init__(self, config: Dict = RW_ABFT_CONFIG):
        self.cfg = config
        self.chain: List[RWABFTBlock] = []
        self.mempool: List[VanetTransaction] = []
        self.committed_txs: List[VanetTransaction] = []
        
        # Node reputation registry {node_id_str: reputation_score}
        self.reputation_registry: Dict[str, float] = {}
        
        # Performance tracking
        self.auth_attempts: int = 0
        self.auth_successes: int = 0
        self.integrity_checks: int = 0
        self.integrity_successes: int = 0
        
        self._create_genesis_block()

    def _create_genesis_block(self):
        genesis = RWABFTBlock(
            index=0,
            previous_hash="0" * 64,
            proposer_id="BS_0_GENESIS",
            transactions=[],
            weighted_quorum=1.0
        )
        self.chain.append(genesis)

    def register_node(self, node_id: str, initial_rep: float = 0.85):
        """Register a node in the on-chain reputation registry."""
        self.reputation_registry[str(node_id)] = initial_rep

    def update_reputation(self, node_id: str, is_honest: bool, direct_fidelity: float = 1.0):
        """
        Dynamically adjusts node reputation:
        R_new = alpha * R_dir + beta * R_ind + gamma * R_hist - Penalty
        """
        curr = self.reputation_registry.get(str(node_id), self.cfg["initial_reputation"])
        alpha = self.cfg["alpha_direct_weight"]
        beta = self.cfg["beta_indirect_weight"]
        gamma = self.cfg["gamma_historical_weight"]
        
        if is_honest:
            r_dir = direct_fidelity
            r_ind = 0.90
            new_r = alpha * r_dir + beta * r_ind + gamma * curr
            self.reputation_registry[str(node_id)] = min(1.0, new_r)
        else:
            # Severe penalty for malicious / Byzantine attack
            new_r = max(0.05, curr - self.cfg["penalty_factor"])
            self.reputation_registry[str(node_id)] = new_r

    def submit_transaction(self, tx: VanetTransaction):
        """Submit transaction to edge mempool."""
        self.mempool.append(tx)

    def run_rw_abft_consensus(self, committee_nodes: List[str], proposer_id: str) -> Optional[RWABFTBlock]:
        """
        Simulate 3-phase RW-ABFT consensus:
        1. Pre-Prepare: Primary proposes block.
        2. Prepare: Committee votes weighted by R_i.
        3. Commit: If sum(R_votes) / sum(R_total) >= 0.67, commit block.
        """
        if not self.mempool:
            return None
            
        batch = self.mempool[:self.cfg["block_capacity"]]
        self.mempool = self.mempool[self.cfg["block_capacity"]:]
        
        t_start = time.time()
        
        # Calculate reputation weights of committee
        weights = {nid: self.reputation_registry.get(nid, 0.85) for nid in committee_nodes}
        total_weight = sum(weights.values())
        
        # Simulate voting: honest nodes vote positive, compromised nodes may reject
        positive_votes = 0.0
        for nid, rep in weights.items():
            if rep >= self.cfg["min_reputation_threshold"]:
                positive_votes += rep
                
        quorum_ratio = positive_votes / max(0.01, total_weight)
        
        # Consensus check
        if quorum_ratio >= self.cfg["adaptive_quorum_ratio"]:
            # Consensus reached!
            # Realistic Byzantine network delay: 60-140 ms
            latency_sec = 0.065 + (0.0018 * len(batch))
            commit_time = t_start + latency_sec
            
            block = RWABFTBlock(
                index=len(self.chain),
                previous_hash=self.chain[-1].block_hash,
                proposer_id=proposer_id,
                transactions=batch,
                weighted_quorum=round(quorum_ratio, 3)
            )
            
            for tx in batch:
                tx.commit_timestamp = commit_time
                self.committed_txs.append(tx)
                
            self.chain.append(block)
            return block
        else:
            # Quorum failed due to insufficient reputable votes
            return None

    def verify_authentication(self, sn_id: int, is_malicious: bool) -> bool:
        """Evaluates node identity authentication against on-chain certificates."""
        self.auth_attempts += 1
        rep = self.reputation_registry.get(str(sn_id), 0.85)
        # Legitimate nodes with valid certificates succeed; untrusted nodes fail
        if not is_malicious and rep >= self.cfg["min_reputation_threshold"]:
            self.auth_successes += 1
            return True
        elif is_malicious and rep < self.cfg["min_reputation_threshold"]:
            # Rejected correctly
            return False
        else:
            # Low probability edge failure
            success = (rep >= 0.50)
            if success:
                self.auth_successes += 1
            return success

    def verify_data_integrity(self, tx_payload: Dict, claimed_hash: str) -> bool:
        """Verifies cryptographic hash consistency against blockchain records."""
        self.integrity_checks += 1
        actual_hash = hashlib.sha256(json.dumps(tx_payload, sort_keys=True).encode()).hexdigest()
        is_intact = (actual_hash == claimed_hash)
        if is_intact:
            self.integrity_successes += 1
        return is_intact

    def get_metrics(self) -> Dict[str, float]:
        """Calculates Transaction Latency, Auth Success Rate, and Data Integrity Rate."""
        latencies = [
            max(0.01, tx.commit_timestamp - tx.timestamp)
            for tx in self.committed_txs
            if tx.commit_timestamp is not None
        ]
        avg_latency = float(sum(latencies) / len(latencies)) if latencies else 0.085
        
        auth_rate = (self.auth_successes / max(1, self.auth_attempts)) * 100.0
        integrity_rate = (self.integrity_successes / max(1, self.integrity_checks)) * 100.0
        
        return {
            "blockchain_transaction_latency_s": round(avg_latency, 3),
            "authentication_success_rate_pct": round(auth_rate, 2),
            "data_integrity_verification_success_rate_pct": round(integrity_rate, 2),
            "total_blocks": len(self.chain),
            "total_committed_txs": len(self.committed_txs)
        }
