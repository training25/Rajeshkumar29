"""
================================================================================
Configuration Parameters for:
Trust-Aware Clustering based Congestion Control and Malicious Attack Mitigation
for Reliable VANET Data Sharing in Blockchain
================================================================================
"""

import os

# Base Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
MODELS_DIR = os.path.join(BASE_DIR, "saved_models")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

# ----------------------------------------------------------------------
# 1. Three-Tier VANET Architecture & Physical Layer
# ----------------------------------------------------------------------
TOPOLOGY_CONFIG = {
    "num_sensor_nodes": 60,           # Number of vehicular Sensor Nodes (SNs)
    "num_cluster_heads": 8,           # Dynamically elected Cluster Heads (CHs)
    "num_base_stations": 4,           # Roadside Base Stations (BSs)
    "area_width": 2500.0,             # Area width (meters)
    "area_height": 2500.0,            # Area height (meters)
    "min_speed": 10.0,                # Minimum vehicle speed (m/s) (~36 km/h)
    "max_speed": 35.0,                # Maximum vehicle speed (m/s) (~126 km/h)
    "tx_range_sn": 250.0,             # SN-to-SN / SN-to-CH transmission range (meters)
    "tx_range_ch": 450.0,             # CH-to-CH inter-cluster range (meters)
    "tx_range_bs": 800.0,             # Base Station coverage radius (meters)
    "simulation_time": 100,           # Total simulation time (seconds)
    "time_step": 1.0,                 # Simulation time step (seconds)
    "packet_size_bits": 8192,         # Standard packet size (1 KB = 8192 bits)
    "max_queue_size": 120,            # Maximum buffer queue capacity per node
    "tx_power_watt": 0.5,             # Transmission power (W)
    "rx_power_watt": 0.2,             # Reception power (W)
    "path_loss_exponent": 2.8,        # Urban/Highway wireless path loss
    "noise_floor_dbm": -95.0,         # Wireless background noise floor (dBm)
    "malicious_ratio": 0.20,          # 20% malicious/adversarial nodes
}

# ----------------------------------------------------------------------
# 2. Blockchain & RW-ABFT Consensus Configuration
# ----------------------------------------------------------------------
RW_ABFT_CONFIG = {
    "block_capacity": 50,             # Max transactions per block
    "committee_size": 8,              # Validator committee (BSs + primary CHs)
    "f_faulty_tolerance": 2,          # Max tolerated Byzantine nodes
    "min_reputation_threshold": 0.50, # Minimum reputation for consensus voting
    "initial_reputation": 0.85,       # Baseline reputation for legitimate nodes
    "alpha_direct_weight": 0.55,      # Weight of direct communication fidelity
    "beta_indirect_weight": 0.30,     # Weight of multi-hop recommendations
    "gamma_historical_weight": 0.15,  # Weight of past ledger reputation
    "penalty_factor": 0.40,           # Penalty deducted upon confirmed attack
    "adaptive_quorum_ratio": 0.67,    # 2/3 reputation-weighted threshold
}

# ----------------------------------------------------------------------
# 3. Clustering-based Trust-Aware Lungfish Optimizer (CTLO)
# ----------------------------------------------------------------------
CTLO_CONFIG = {
    "population_size": 30,            # Population of candidate lungfish routing paths
    "max_iterations": 25,             # Optimization iterations per routing epoch
    "estivation_threshold": 0.70,     # Queue congestion threshold triggering estivation
    "mucus_cocoon_factor": 1.35,      # Fortified trust barrier shielding against hostile links
    "burrowing_depth_scale": 0.85,    # Fine-grained local search parameter
    "swimming_burst_speed": 1.50,     # Rapid path exploration parameter
    
    # Multi-Objective Weights (Sum = 1.0)
    "w_trust": 0.35,                  # Weight for node trustworthiness
    "w_link_quality": 0.30,           # Weight for SNR and Link Expiration Time (LET)
    "w_congestion": 0.20,             # Weight for queue occupancy & buffer health
    "w_delay": 0.15,                  # Weight for hop count and latency minimization
}

# ----------------------------------------------------------------------
# 4. Federated Alpha-Regularized Continual Learning (FARCL)
# ----------------------------------------------------------------------
FARCL_CONFIG = {
    "num_rounds": 15,                 # Federated aggregation rounds
    "local_epochs": 4,                # Local training epochs per CH
    "batch_size": 32,                 # Mini-batch size
    "learning_rate": 0.002,           # Optimizer learning rate
    "alpha_reg": 0.50,                # Alpha continual learning regularization parameter
    "fisher_damping": 1e-4,           # Damping term for Fisher Information Matrix
    "cnn_filters": 32,                # 1D-CNN filters for spatial feature extraction
    "hidden_dim": 64,                 # Bi-GRU hidden state dimension for temporal learning
    "num_features": 12,               # Number of vehicular traffic features
    "num_classes": 5,                 # Normal, Sybil, DDoS, Spoofing, Replay
}

ATTACK_CLASSES = {
    0: "Normal",
    1: "Sybil",
    2: "DDoS_Flooding",
    3: "Spoofing_FalseInfo",
    4: "Replay_Attack"
}

# ----------------------------------------------------------------------
# 5. Verifiable Rate-Limit Tokens (VRTs) Configuration
# ----------------------------------------------------------------------
VRT_CONFIG = {
    "token_bucket_capacity": 50,      # Max tokens an SN can burst
    "token_refill_rate": 15.0,        # Refill tokens per second
    "token_validity_epoch": 30.0,     # Seconds an issued VRT remains valid
    "hash_secret_key": "VRT_SECRET_VANET_2026",
    "penalty_cooldown_seconds": 20.0, # Cooldown penalty when rate limit is breached
}
