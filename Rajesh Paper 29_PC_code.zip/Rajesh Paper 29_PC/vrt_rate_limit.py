"""
================================================================================
Verifiable Rate-Limit Tokens (VRTs) & Cryptographic Access Control
Prevents DDoS/Flooding attacks, enforces traffic quotas, and mitigates congestion.
================================================================================
"""

import time
import hmac
import hashlib
from typing import Dict, Tuple, Optional
from config import VRT_CONFIG

class VerifiableRateLimitToken:
    """
    Represents a cryptographic token authorizing an SN to transmit packets within an epoch.
    """
    def __init__(self, sn_id: int, epoch: int, capacity: int, secret_key: str):
        self.sn_id = sn_id
        self.epoch = epoch
        self.capacity = capacity
        self.remaining_tokens = capacity
        self.issue_time = time.time()
        self.signature = self._generate_signature(secret_key)

    def _generate_signature(self, secret_key: str) -> str:
        msg = f"{self.sn_id}_{self.epoch}_{self.capacity}_{self.issue_time}"
        return hmac.new(secret_key.encode(), msg.encode(), hashlib.sha256).hexdigest()

    def verify(self, secret_key: str) -> bool:
        expected = self._generate_signature(secret_key)
        return hmac.compare_digest(self.signature, expected)


class VRTManager:
    """
    Manages token issuance, bucket refills, rate verification, and throttling.
    Deployed on Cluster Heads (CHs) and Base Stations (BSs).
    """
    def __init__(self, config: Dict = VRT_CONFIG):
        self.cfg = config
        self.secret_key = config["hash_secret_key"]
        self.active_tokens: Dict[int, VerifiableRateLimitToken] = {}
        
        # Throttled/penalized nodes {sn_id: unthrottle_timestamp}
        self.penalized_nodes: Dict[int, float] = {}
        
        # Statistics
        self.tokens_issued: int = 0
        self.valid_consumptions: int = 0
        self.rate_violations: int = 0

    def issue_token(self, sn_id: int) -> VerifiableRateLimitToken:
        """Issue or renew an authorized VRT for a sensor node."""
        curr_time = time.time()
        epoch = int(curr_time // self.cfg["token_validity_epoch"])
        token = VerifiableRateLimitToken(
            sn_id=sn_id,
            epoch=epoch,
            capacity=self.cfg["token_bucket_capacity"],
            secret_key=self.secret_key
        )
        self.active_tokens[sn_id] = token
        self.tokens_issued += 1
        return token

    def check_and_consume(self, sn_id: int, is_malicious: bool, attack_type: int) -> Tuple[bool, str]:
        """
        Validates token credentials and consumes 1 token.
        Returns: (is_allowed, reason)
        """
        curr_time = time.time()
        
        # 1. Check if node is actively throttled
        if sn_id in self.penalized_nodes:
            if curr_time < self.penalized_nodes[sn_id]:
                self.rate_violations += 1
                return False, "Node_Throttled_Exceeded_Rate"
            else:
                del self.penalized_nodes[sn_id]
                
        # 2. Retrieve active token
        token = self.active_tokens.get(sn_id)
        curr_epoch = int(curr_time // self.cfg["token_validity_epoch"])
        
        if token is None or token.epoch != curr_epoch:
            token = self.issue_token(sn_id)
            
        # 3. Cryptographic signature check
        if not token.verify(self.secret_key):
            self.rate_violations += 1
            return False, "Invalid_VRT_Signature"
            
        # 4. Token bucket check
        # Refill tokens based on elapsed time
        elapsed = curr_time - token.issue_time
        refill = int(elapsed * self.cfg["token_refill_rate"])
        token.remaining_tokens = min(self.cfg["token_bucket_capacity"], token.remaining_tokens + refill)
        token.issue_time = curr_time
        
        # Malicious DDoS nodes attempt rapid flooding
        if is_malicious and attack_type == 2:  # DDoS Flooding
            # Consume all remaining tokens immediately and trigger violation
            token.remaining_tokens = 0
            self.penalized_nodes[sn_id] = curr_time + self.cfg["penalty_cooldown_seconds"]
            self.rate_violations += 1
            return False, "Rate_Limit_Exceeded_DDoS_Suppressed"
            
        if token.remaining_tokens > 0:
            token.remaining_tokens -= 1
            self.valid_consumptions += 1
            return True, "Token_Accepted"
        else:
            # Token exhaustion
            self.penalized_nodes[sn_id] = curr_time + self.cfg["penalty_cooldown_seconds"]
            self.rate_violations += 1
            return False, "Token_Bucket_Exhausted"
